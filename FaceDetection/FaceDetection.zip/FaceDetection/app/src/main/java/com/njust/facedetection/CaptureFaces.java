package com.njust.facedetection;

import android.support.v4.app.Fragment;

public class CaptureFaces extends Fragment {
}
